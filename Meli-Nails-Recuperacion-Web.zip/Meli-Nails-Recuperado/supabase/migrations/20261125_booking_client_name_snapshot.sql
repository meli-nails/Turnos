-- Meli Nails · Fix de nombres por reserva
-- Esta migración ya fue aplicada en el proyecto Supabase de producción.
begin;
alter table public.bookings add column if not exists client_name text;
update public.bookings b set client_name=c.full_name
from public.clients c where c.id=b.client_id and (b.client_name is null or b.client_name='');
comment on column public.bookings.client_name is
  'Nombre del cliente capturado al crear esta reserva; no cambia si se actualiza la ficha del cliente.';
commit;
